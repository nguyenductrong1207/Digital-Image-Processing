A = imread('sample.ppm');
imshow(A)
imwrite(A,'newImg1.ppm');